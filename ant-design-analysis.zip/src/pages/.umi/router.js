import React from 'react';
import { Router as DefaultRouter, Route, Switch } from 'react-router-dom';
import dynamic from 'umi/dynamic';
import renderRoutes from 'umi/_renderRoutes';
import RendererWrapper0 from 'C:/Users/Administrator/Desktop/jxy/ant-design-analysis/src/pages/.umi/LocaleWrapper.jsx'
import _dvaDynamic from 'dva/dynamic'

let Router = require('dva/router').routerRedux.ConnectedRouter;

let routes = [
  {
    "path": "/user",
    "component": _dvaDynamic({
  
  component: () => import('../../layouts/UserLayout'),
  LoadingComponent: require('C:/Users/Administrator/Desktop/jxy/ant-design-analysis/src/components/PageLoading/index').default,
}),
    "routes": [
      {
        "path": "/user",
        "redirect": "/user/login",
        "exact": true
      },
      {
        "path": "/user/login",
        "name": "login",
        "icon": "block",
        "component": _dvaDynamic({
  
  component: () => import('../Login'),
  LoadingComponent: require('C:/Users/Administrator/Desktop/jxy/ant-design-analysis/src/components/PageLoading/index').default,
}),
        "exact": true
      },
      {
        "component": () => React.createElement(require('C:/Users/Administrator/Desktop/jxy/ant-design-analysis/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
      }
    ]
  },
  {
    "path": "/",
    "component": _dvaDynamic({
  
  component: () => import('../../layouts/BasicLayout'),
  LoadingComponent: require('C:/Users/Administrator/Desktop/jxy/ant-design-analysis/src/components/PageLoading/index').default,
}),
    "routes": [
      {
        "path": "/",
        "redirect": "/analysis",
        "exact": true
      },
      {
        "path": "/analysis",
        "name": "analysis",
        "icon": "smile",
        "routes": [
          {
            "path": "/analysis",
            "redirect": "/analysis/analysis",
            "exact": true
          },
          {
            "path": "/analysis/analysis",
            "name": "analysis",
            "component": _dvaDynamic({
  
  component: () => import('../Index'),
  LoadingComponent: require('C:/Users/Administrator/Desktop/jxy/ant-design-analysis/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/analysis/config",
            "name": "config",
            "component": _dvaDynamic({
  
  component: () => import('../Index/config'),
  LoadingComponent: require('C:/Users/Administrator/Desktop/jxy/ant-design-analysis/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/analysis/history",
            "name": "history",
            "component": _dvaDynamic({
  
  component: () => import('../Index/history'),
  LoadingComponent: require('C:/Users/Administrator/Desktop/jxy/ant-design-analysis/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "component": () => React.createElement(require('C:/Users/Administrator/Desktop/jxy/ant-design-analysis/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
          }
        ]
      },
      {
        "path": "/account",
        "name": "account",
        "icon": "user",
        "routes": [
          {
            "path": "/account/center",
            "name": "center",
            "component": _dvaDynamic({
  
  component: () => import('../account/center'),
  LoadingComponent: require('C:/Users/Administrator/Desktop/jxy/ant-design-analysis/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/account/changePwd",
            "name": "changePwd",
            "component": _dvaDynamic({
  
  component: () => import('../account/changePwd'),
  LoadingComponent: require('C:/Users/Administrator/Desktop/jxy/ant-design-analysis/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "component": () => React.createElement(require('C:/Users/Administrator/Desktop/jxy/ant-design-analysis/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
          }
        ]
      },
      {
        "component": () => React.createElement(require('C:/Users/Administrator/Desktop/jxy/ant-design-analysis/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
      }
    ]
  },
  {
    "component": () => React.createElement(require('C:/Users/Administrator/Desktop/jxy/ant-design-analysis/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
  }
];
window.g_routes = routes;
window.g_plugins.applyForEach('patchRoutes', { initialValue: routes });

// route change handler
function routeChangeHandler(location, action) {
  window.g_plugins.applyForEach('onRouteChange', {
    initialValue: {
      routes,
      location,
      action,
    },
  });
}
window.g_history.listen(routeChangeHandler);
routeChangeHandler(window.g_history.location);

export default function RouterWrapper() {
  return (
<RendererWrapper0>
          <Router history={window.g_history}>
      { renderRoutes(routes, {}) }
    </Router>
        </RendererWrapper0>
  );
}
