export default {
  'menu.welcome': 'Welcome',
  'menu.more-blocks': 'More Blocks',

  'menu.account.center': 'Central da Conta',
  'menu.account.settings': 'Configurar Conta',
  'menu.account.trigger': 'Disparar Erro',
  'menu.account.logout': 'Sair',
};
