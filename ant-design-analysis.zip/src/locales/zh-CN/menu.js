export default {
  'menu.welcome': '欢迎',
  'menu.more-blocks': '更多区块',
  'menu.analysis': '故障与分析',
  'menu.analysis.analysis': '数据分析',
  'menu.analysis.history': '历史数据',
  'menu.analysis.config': '调参预测',

  'menu.account': '账户管理',
  'menu.account.center': '个人中心',
  'menu.account.changePwd': '修改密码',
  'menu.account.settings': '个人设置',
  'menu.account.trigger': '触发报错',
  'menu.account.logout': '退出登录',
};
