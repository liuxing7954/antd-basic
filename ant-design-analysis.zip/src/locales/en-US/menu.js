export default {
  'menu.welcome': 'Welcome',
  'menu.more-blocks': 'More Blocks',

  'menu.account.center': 'Account Center',
  'menu.account.settings': 'Account Settings',
  'menu.account.trigger': 'Trigger Error',
  'menu.account.logout': 'Logout',
};
