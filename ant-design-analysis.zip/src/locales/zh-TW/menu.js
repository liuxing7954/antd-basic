export default {
  'menu.welcome': '歡迎',
  'menu.more-blocks': '更多區塊',

  'menu.account.center': '個人中心',
  'menu.account.settings': '個人設置',
  'menu.account.trigger': '觸發報錯',
  'menu.account.logout': '退出登錄',
};
